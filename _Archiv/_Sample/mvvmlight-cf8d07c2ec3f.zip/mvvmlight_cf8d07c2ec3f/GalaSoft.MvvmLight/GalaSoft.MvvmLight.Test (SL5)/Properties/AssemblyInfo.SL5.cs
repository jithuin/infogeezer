﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("5CD7CAB3-F745-47F4-80C7-917031A52E33")]
