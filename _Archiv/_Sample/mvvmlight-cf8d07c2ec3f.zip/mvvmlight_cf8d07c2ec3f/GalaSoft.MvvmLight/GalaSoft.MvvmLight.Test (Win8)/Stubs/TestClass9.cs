﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GalaSoft.MvvmLight.Test.Stubs
{
    public class TestClass9
    {
        public TestClass9()
        {
            
        }

        internal TestClass9(string param)
        {
            
        }
    }
}
