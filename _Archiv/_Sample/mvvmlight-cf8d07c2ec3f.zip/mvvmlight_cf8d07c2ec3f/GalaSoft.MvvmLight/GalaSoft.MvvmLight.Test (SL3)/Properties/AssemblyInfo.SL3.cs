﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("9BBC6BCB-D0CA-44E1-9C9C-A6D9BD867970")]
