﻿using System.Windows;
using System.Windows.Controls;

namespace $safeprojectname$
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}