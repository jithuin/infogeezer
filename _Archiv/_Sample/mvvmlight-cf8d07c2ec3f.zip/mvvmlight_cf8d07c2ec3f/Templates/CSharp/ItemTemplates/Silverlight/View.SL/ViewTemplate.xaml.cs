﻿using System.Windows;
using System.Windows.Controls;

namespace $rootnamespace$
{
    /// <summary>
    /// Description for $safeitemname$.
    /// </summary>
    public partial class $safeitemname$ : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the $safeitemname$ class.
        /// </summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}