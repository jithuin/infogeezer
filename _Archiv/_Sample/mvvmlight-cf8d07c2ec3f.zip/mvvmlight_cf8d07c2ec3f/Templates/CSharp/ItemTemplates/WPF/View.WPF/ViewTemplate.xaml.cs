﻿using System.Windows;

namespace $rootnamespace$
{
    /// <summary>
    /// Description for $safeitemname$.
    /// </summary>
    public partial class $safeitemname$ : Window
    {
        /// <summary>
        /// Initializes a new instance of the $safeitemname$ class.
        /// </summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}