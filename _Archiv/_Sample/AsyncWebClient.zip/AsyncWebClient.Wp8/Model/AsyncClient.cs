﻿using System;
using System.Net;
using System.Threading.Tasks;

namespace AsyncWebClient.Model
{
    public class AsyncClient
    {
        public Task<string> Get(Uri uri)
        {
            var tcs = new TaskCompletionSource<string>();

            try
            {
                var client = new WebClient();
                client.DownloadStringCompleted += (s, e) =>
                {
                    if (e.Error != null)
                    {
                        tcs.SetException(e.Error);
                    }
                    else
                    {
                        tcs.SetResult(e.Result);
                    }
                };

                client.DownloadStringAsync(uri);
            }
            catch (Exception ex)
            {
                tcs.SetException(ex);
            }

            return tcs.Task;
        }
    }
}