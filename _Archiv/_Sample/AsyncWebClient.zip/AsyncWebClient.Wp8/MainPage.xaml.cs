﻿using System.Windows;
using AsyncWebClient.Model;

namespace AsyncWebClient
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            Execute();
        }

        private static async void Execute()
        {
            var service = new DataService();
            var content = await service.GetData();
            MessageBox.Show(content);
        }
    }
}