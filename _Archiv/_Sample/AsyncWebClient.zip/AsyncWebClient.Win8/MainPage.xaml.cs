﻿using AsyncWebClient.Model;
using Windows.UI.Popups;

namespace AsyncWebClient
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            Execute();
        }

        private static async void Execute()
        {
            var service = new DataService();
            var content = await service.GetData();

            var dialog = new MessageDialog(content);
            dialog.ShowAsync();
        }
    }
}