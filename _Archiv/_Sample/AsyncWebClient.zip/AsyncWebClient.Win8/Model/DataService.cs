﻿using System;
using System.Threading.Tasks;

namespace AsyncWebClient.Model
{
    public class DataService
    {
        public async Task<string> GetData()
        {
            var client = new AsyncClient();
            return await client.Get(
                new Uri(
                    "http://www.galasoft.ch/labs/friends/handle.ashx?code=A7DFF044AACD45F6AD91F2ADF9306397&action=get"));
        }
    }
}