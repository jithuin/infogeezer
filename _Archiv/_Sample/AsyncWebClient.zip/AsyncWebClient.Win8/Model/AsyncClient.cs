﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace AsyncWebClient.Model
{
    public class AsyncClient
    {
        public async Task<string> Get(Uri uri)
        {
            var client = new HttpClient();
            return await client.GetStringAsync(uri);
        }
    }
}