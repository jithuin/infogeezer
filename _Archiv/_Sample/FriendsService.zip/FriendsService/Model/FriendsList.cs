using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace FriendsService.Model
{
    public class FriendsList
    {
        [JsonProperty("data")]
        public List<Friend> Data
        {
            get;
            set;
        }
    }
}