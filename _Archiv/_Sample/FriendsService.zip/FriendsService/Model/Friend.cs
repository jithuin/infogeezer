using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace FriendsService.Model
{
    public class Friend
    {
        [JsonProperty("id")]
        public string Id
        {
            get;
            set;
        }

        [JsonProperty("first_name")]
        public string FirstName
        {
            get;
            set;
        }

        [JsonProperty("last_name")]
        public string LastName
        {
            get;
            set;
        }

        [JsonProperty("picture")]
        public string PictureUrl
        {
            get;
            set;
        }

        [JsonProperty("location")]
        public string Location
        {
            get;
            set;
        }

        [JsonProperty("message")]
        public string Message
        {
            get;
            set;
        }

        public void Update(Friend updatedFriend)
        {
            FirstName = updatedFriend.FirstName;
            LastName = updatedFriend.LastName;
        }
    }
}