﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using FriendsService.Model;
using Newtonsoft.Json;

namespace FriendsService
{
    public class Get : IHttpHandler
    {
        private List<Friend> _friendsList;
        private static readonly ReaderWriterLockSlim Rwl = new ReaderWriterLockSlim();

        public void ProcessRequest(HttpContext context)
        {
            var code = context.Request.QueryString[Constants.QueryKeyCode];

            if (code == null
                || code != Constants.Code)
            {
                context.Response.ContentType = "text/plain";
                context.Response.Write("Invalid code");
                return;
            }

            var action = context.Request.QueryString[Constants.QueryKeyAction];

            if (action == null)
            {
                context.Response.ContentType = "text/plain";
                context.Response.Write("Unknown action");
                return;
            }

            switch (action)
            {
                case Constants.ActionGet:
                    GetFriendsList(context);
                    return;

                case Constants.ActionSave:
                    SaveFriend(context);
                    return;

                case Constants.ActionReset:
                    Reset(context);
                    return;
            }
        }

        private void GetFriendsList(HttpContext context)
        {
            Rwl.EnterReadLock();
            context.Response.ContentType = "application/json";

            try
            {
                var path = context.Server.MapPath("Data/FacebookFriendsList.txt");
                string fileContent;

                using (var reader = new StreamReader(path))
                {
                    fileContent = reader.ReadToEnd();
                }

                context.Response.Write(fileContent);
            }
            catch (Exception)
            {
                context.Response.Write("{}");
            }
            finally
            {
                Rwl.ExitReadLock();
            }
        }

        private void SaveFriend(HttpContext context)
        {
            CheckLoad(context);

            Rwl.EnterWriteLock();

            try
            {
                Friend updatedFriend;

                using (var inputStream = context.Request.InputStream)
                {
                    using (var reader = new StreamReader(inputStream))
                    {
                        var json = reader.ReadToEnd();
                        updatedFriend = JsonConvert.DeserializeObject<Friend>(json);
                    }
                }

                if (updatedFriend == null)
                {
                    return;
                }

                var existing = _friendsList.FirstOrDefault(f => f.Id == updatedFriend.Id);

                if (existing == null)
                {
                    // New friend
                    var maxId = _friendsList.OrderBy(f => f.Id).Last().Id;
                    updatedFriend.Id = maxId + 1;
                    _friendsList.Add(updatedFriend);
                }
                else
                {
                    existing.Update(updatedFriend);
                }

                var path = context.Server.MapPath("Data/FacebookFriendsList.txt");

                var list = new FriendsList
                {
                    Data = _friendsList
                };

                var outputJson = JsonConvert.SerializeObject(list);

                using (var stream = File.Open(path, FileMode.Create, FileAccess.Write))
                {
                    using (var writer = new StreamWriter(stream))
                    {
                        writer.Write(outputJson);
                    }
                }

                context.Response.Write(updatedFriend.Id);
            }
            catch (Exception)
            {
                context.Response.Write("0");
            }
            finally
            {
                Rwl.ExitWriteLock();
            }
        }

        private void Reset(HttpContext context)
        {
            Rwl.EnterWriteLock();

            try
            {
                var inputPath = context.Server.MapPath("Data/FacebookFriendsList.Work.txt");
                var outputPath = context.Server.MapPath("Data/FacebookFriendsList.txt");

                using (var reader = new StreamReader(inputPath))
                {
                    using (var writer = new StreamWriter(outputPath))
                    {
                        writer.Write(reader.ReadToEnd());
                    }
                }
            }
            finally
            {
                Rwl.ExitWriteLock();
            }
        }

        private void CheckLoad(HttpContext context)
        {
            if (_friendsList == null)
            {
                Rwl.EnterReadLock();

                try
                {
                    var path = context.Server.MapPath("Data/FacebookFriendsList.txt");
                    _friendsList = new List<Friend>();

                    using (var reader = new StreamReader(path))
                    {
                        var json = reader.ReadToEnd();

                        var serializer = new JsonSerializer();
                        var result = JsonConvert.DeserializeObject<FriendsList>(json);

                        _friendsList = result.Data.ToList();

                    }

                    //using (var stream = File.OpenRead(path))
                    //{
                    //    var reader = new StreamReader(stream);
                    //    Debug.WriteLine(reader.ReadToEnd());
                    //    stream.Position = 0;

                    //    var serializer = new DataContractJsonSerializer(typeof (FriendsList));
                    //    var result = (FriendsList)serializer.ReadObject(stream);
                    //    _friendsList = result.Data.ToList();

                    //    reader.Close();
                    //    reader.Dispose();
                    //}
                }
                finally
                {
                    Rwl.ExitReadLock();
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}