﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Friends.Lib.Model;
using GalaSoft.MvvmLight;

#if DEBUG
namespace Friends.Lib.Design
{
    public class DesignFriendsService : IDataService
    {
        public Task<IList<Friend>> GetFriends()
        {
            var result = new List<Friend>();

            for (var index = 0; index < 30; index++)
            {
                var friend = new Friend
                {
                    FirstName = "FirstName" + index,
                    LastName = "LastName" + index,
                    PictureUrl = "http://www.galasoft.ch/labs/friends/Data/LogoHead128.png"
                };

                friend.IsDirty = index % 2 == 0;
                result.Add(friend);
            }

            return Task.FromResult((IList<Friend>)result);
        }

        public Task<string> SaveFriend(Friend friend)
        {
            return Task.FromResult("0");
        }
    }
}
#endif
