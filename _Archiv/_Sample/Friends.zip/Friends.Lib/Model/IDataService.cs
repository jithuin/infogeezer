﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Friends.Lib.Model
{
    public interface IDataService
    {
        Task<IList<Friend>> GetFriends();
        Task<string> SaveFriend(Friend friend);
    }
}