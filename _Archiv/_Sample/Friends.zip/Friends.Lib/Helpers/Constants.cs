﻿namespace Friends.Lib.Helpers
{
    public static class Constants
    {
        public const string ActionGet = "get";
        public const string ActionReset = "reset";
        public const string ActionSave = "save";
        public const string Code = "A7DFF044AACD45F6AD91F2ADF9306397";
        public const string QueryKeyAction = "action";
        public const string QueryKeyCode = "code";
    }
}