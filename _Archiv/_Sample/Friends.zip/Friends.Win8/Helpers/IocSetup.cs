﻿using Friends.Lib.Helpers;
using GalaSoft.MvvmLight.Ioc;

namespace Friends.Helpers
{
    public class IocSetup
    {
        static IocSetup()
        {
            SimpleIoc.Default.Register<INavigationService>(() => new NavigationService());
        }
    }
}
