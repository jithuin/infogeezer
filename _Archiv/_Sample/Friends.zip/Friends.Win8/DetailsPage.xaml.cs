﻿using Friends.Lib;
using Windows.UI.Xaml.Navigation;

namespace Friends
{
    public sealed partial class DetailsPage
    {
        public DetailsPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var friend = e.Parameter as Friend;
            DataContext = friend;
        }
    }
}
