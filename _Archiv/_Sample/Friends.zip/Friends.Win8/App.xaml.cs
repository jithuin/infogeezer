using System;
using System.Threading.Tasks;
using Friends.Helpers;
using Friends.Lib.Helpers;
using Friends.Win8;
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Threading;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Friends
{
    /// <summary>
    /// Provides application-specific behavior to supplement the default Application class.
    /// </summary>
    sealed partial class App : IDialogService
    {
        /// <summary>
        /// Initializes the singleton application object.  This is the first line of authored code
        /// executed, and as such is the logical equivalent of main() or WinMain().
        /// </summary>
        public App()
        {
            InitializeComponent();
            Suspending += OnSuspending;
        }

        /// <summary>
        /// Invoked when the application is launched normally by the end user.  Other entry points
        /// will be used when the application is launched to open a specific file, to display
        /// search results, and so forth.
        /// </summary>
        /// <param name="args">Details about the launch request and process.</param>
        protected override void OnLaunched(LaunchActivatedEventArgs args)
        {
            SimpleIoc.Default.Register<IDialogService>(() => this);

            Frame rootFrame = Window.Current.Content as Frame;

            // Do not repeat app initialization when the Window already has content,
            // just ensure that the window is active
            if (rootFrame == null)
            {
                // Create a Frame to act as the navigation context and navigate to the first page
                rootFrame = new Frame();

                if (args.PreviousExecutionState == ApplicationExecutionState.Terminated)
                {
                    //TODO: Load state from previously suspended application
                }

                // Place the frame in the current Window
                Window.Current.Content = rootFrame;
            }

            if (rootFrame.Content == null)
            {
                // When the navigation stack isn't restored navigate to the first page,
                // configuring the new page by passing required information as a navigation
                // parameter
                if (!rootFrame.Navigate(typeof(MainPage), args.Arguments))
                {
                    throw new Exception("Failed to create initial page");
                }
            }
            // Ensure the current window is active
            Window.Current.Activate();

            DispatcherHelper.Initialize();
        }

        /// <summary>
        /// Invoked when application execution is being suspended.  Application state is saved
        /// without knowing whether the application will be terminated or resumed with the contents
        /// of memory still intact.
        /// </summary>
        /// <param name="sender">The source of the suspend request.</param>
        /// <param name="e">Details about the suspend request.</param>
        private void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            //TODO: Save application state and stop any background activity
            deferral.Complete();
        }

        public async Task ShowError(string message, string title, string buttonText, Action afterHideCallback)
        {
            var dialog = new MessageDialog(message, title ?? string.Empty);

            dialog.Commands.Add(
                new UICommand(
                    buttonText,
                    c =>
                    {
                        if (afterHideCallback != null)
                        {
                            afterHideCallback();
                        }
                    }));

            dialog.CancelCommandIndex = 0;
            await dialog.ShowAsync();
        }

        public async Task ShowError(Exception error, string title, string buttonText, Action afterHideCallback)
        {
            await ShowError(error.Message, title ?? string.Empty, buttonText, afterHideCallback);
        }

        public async Task ShowMessage(string message, string title)
        {
            var dialog = new MessageDialog(message, title ?? string.Empty);
            await dialog.ShowAsync();
        }

        public async Task ShowMessage(string message, string title, string buttonText, Action afterHideCallback)
        {
            var dialog = new MessageDialog(message, title ?? string.Empty);
            dialog.Commands.Add(
                new UICommand(
                    buttonText,
                    c =>
                    {
                        if (afterHideCallback != null)
                        {
                            afterHideCallback();
                        }
                    }));
            dialog.CancelCommandIndex = 0;
            await dialog.ShowAsync();
        }

        public async Task ShowMessage(
            string message,
            string title,
            string buttonConfirmText,
            string buttonCancelText,
            Action<bool> afterHideCallback)
        {
            var dialog = new MessageDialog(message, title ?? string.Empty);
            dialog.Commands.Add(new UICommand(buttonConfirmText, c => afterHideCallback(true)));
            dialog.Commands.Add(new UICommand(buttonCancelText, c => afterHideCallback(false)));
            dialog.CancelCommandIndex = 1;
            await dialog.ShowAsync();
        }

        public async Task ShowMessageBox(string message, string title)
        {
            var dialog = new MessageDialog(message, title ?? string.Empty);
            await dialog.ShowAsync();
        }
    }
}
