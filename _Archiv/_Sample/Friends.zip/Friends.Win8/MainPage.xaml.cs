﻿using Friends.Lib;
using Friends.Lib.ViewModel;
using GalaSoft.MvvmLight.Threading;
using Windows.Networking.Proximity;
using Windows.UI.Xaml;

namespace Friends
{
    public sealed partial class MainPage
    {
        private readonly ProximityDevice _device;

        public MainPage()
        {
            InitializeComponent();

            _device = ProximityDevice.GetDefault();

            if (_device == null)
            {
                ReceiveButton.IsEnabled = false;
            }
        }

        private void ReceiveClick(object sender, RoutedEventArgs e)
        {
            _device.SubscribeForMessage(
                "Windows.GalaSoft.Friend",
                HandleMessage);
        }

        private void HandleMessage(ProximityDevice sender, ProximityMessage message)
        {
            DispatcherHelper.CheckBeginInvokeOnUI(
                () =>
                {
                    var vm = (MainViewModel)DataContext;
                    vm.UpdateFiend(message.DataAsString);
                });
        }
    }
}
