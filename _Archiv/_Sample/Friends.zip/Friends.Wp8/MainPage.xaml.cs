﻿using System;
using Friends.Lib.ViewModel;

namespace Friends
{
    public partial class MainPage
    {
        public MainViewModel Vm
        {
            get
            {
                return (MainViewModel)DataContext;
            }
        }

        public MainPage()
        {
            InitializeComponent();
        }

        private void RefreshClick(object sender, EventArgs e)
        {
            Vm.RefreshCommand.Execute(null);
        }
    }
}