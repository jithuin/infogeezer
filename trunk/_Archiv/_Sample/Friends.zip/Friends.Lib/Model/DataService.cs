﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Friends.Lib.Helpers;
using Newtonsoft.Json;

namespace Friends.Lib.Model
{
    public class DataService : IDataService
    {
        private const string Json ="{\"data\":[{\"id\":\"1\",\"first_name\":\"Alise\",\"last_name\":\"Bugnion\",\"birthday\":\"10/18/2001\",\"link\":\"http://www.facebook.com/feigenbaum\",\"picture\":\"http://www.galasoft.ch/labs/friends/Data/Pictures/1.jpg\"},{\"id\":\"2\",\"first_name\":\"Laeticia\",\"last_name\":\"Bugnion\",\"birthday\":\"03/29/2004\",\"picture\":\"http://www.galasoft.ch/labs/friends/Data/Pictures/2.jpg\"},{\"id\":\"3\",\"first_name\":\"Paul\",\"last_name\":\"Czywczynski\",\"birthday\":\"03/10/1972\",\"link\":\"http://www.facebook.com/paulczy\",\"picture\":\"http://www.galasoft.ch/labs/friends/Data/Pictures/3.jpg\"}]}";

        private const string UrlBase = "http://www.galasoft.ch/labs/friends/handle.ashx?code={0}&{1}={2}&seed={3}";

        public async Task<IList<Friend>> GetFriends()
        {
            //var json = Json;

            var client = new HttpClient();
            var json = await client.GetStringAsync(
                string.Format(
                    UrlBase, Constants.Code, Constants.QueryKeyAction, Constants.ActionGet, DateTime.Now.Ticks));

            var result = JsonConvert.DeserializeObject<ListOfFriends>(json);

            foreach (var friend in result.Data)
            {
                friend.IsDirty = false;
            }

            return result.Data;
        }

        public async Task<string> SaveFriend(Friend updatedFriend)
        {
            var client = new HttpClient();

            var uri = new Uri(string.Format(
                UrlBase,
                Constants.Code,
                Constants.QueryKeyAction,
                Constants.ActionSave,
                DateTime.Now.Ticks));

            var json = JsonConvert.SerializeObject(updatedFriend);

            try
            {
                var content = new StringContent(json);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var response = await client.PostAsync(uri, content);
                var result = await response.Content.ReadAsStringAsync();

                updatedFriend.IsDirty = false;

                return result;
            }
            catch (Exception)
            {
                return "0";
            }
        }
    }
}
