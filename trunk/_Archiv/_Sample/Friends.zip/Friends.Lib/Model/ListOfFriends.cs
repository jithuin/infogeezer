using System.Collections.Generic;
using Newtonsoft.Json;

namespace Friends.Lib
{
    public class ListOfFriends
    {
        [JsonProperty("data")]
        public List<Friend> Data
        {
            get;
            set;
        }
    }
}